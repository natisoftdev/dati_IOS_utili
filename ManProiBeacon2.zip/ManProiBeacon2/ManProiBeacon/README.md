# AKSwiftSlideMenu

[![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://github.com/matteocrippa/awesome-swift) [![Language](https://img.shields.io/badge/Swift-4.2-orange.svg)](https://swift.org)

Slide Menu (Drawer) in Swift 4.2

Why to use a library everytime?

Let's create our own Slide Menu in Swift 4.2

![Slide Menu Example Image](https://cloud.githubusercontent.com/assets/6905345/10064748/8b39581e-6299-11e5-8829-d003e4069f30.png)

I have uploaded a video for easy way to integrate AKSwiftSlideMenu in your project : 

[![How to integrate AKSwiftSlideMenu - iOS - Swift](https://img.youtube.com/vi/UEOf-mVeEzU/0.jpg)](https://www.youtube.com/watch?v=UEOf-mVeEzU)

I have written an article about this on my website http://ashishkakkad.com/2015/09/create-your-own-slider-menu-drawer-in-swift/ (Old article not updated with Swift versions)

Happy Coding :)
