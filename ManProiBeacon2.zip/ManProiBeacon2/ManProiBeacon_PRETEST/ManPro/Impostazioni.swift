//
//  Impostazioni.swift
//  ManPro.net
//
//  Created by Lorenzo Malferrari on 27/03/19.
//  Copyright © 2019 Natisoft. All rights reserved.
//

import UIKit

class Impostazioni: BaseViewController {
    
    @IBOutlet weak var textFieldDB: UITextField!
    @IBOutlet weak var lbVersioneTesto: UILabel!
    @IBOutlet weak var lbVersioneNumero: UILabel!
    
    //Informazioni sul device
    var nameDevice:String = "" //Nome del device dato da Utente/Casa Madre
    var systemNameDevice:String = "" //Systema operativo installato
    var systemVersionDevice:String = "" //Versione OS
    var modelDevice:String = "" //Modello del device
    var identifierForVendorDevice:String = ""
    var releaseVersionNumber:String = ""
    var buildVersionNumber:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        // Do any additional setup after loading the view.
        
        nameDevice = UIDevice.current.name //Nome del device dato da Utente/Casa Madre
        systemNameDevice = UIDevice.current.systemName //Systema operativo installato
        systemVersionDevice = UIDevice.current.systemVersion //Versione OS
        modelDevice = UIDevice.current.model //Modello del device
        identifierForVendorDevice = UIDevice.current.identifierForVendor!.uuidString
        if let release = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
            self.releaseVersionNumber = release
        }
        if let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String {
            self.buildVersionNumber = build
        }
        
        //print("Informazioni sul Telefono")
        //print(nameDevice)
        //print(systemNameDevice)
        //print(systemVersionDevice)
        //print(modelDevice)
        //print(identifierForVendorDevice)
        //print(releaseVersionNumber)
        //print(buildVersionNumber)
        //print("---------------------------")
        
        textFieldDB.text = UserDefaults.standard.string(forKey: "nameDB") ?? ""
        lbVersioneTesto.text = "Versione dell'applicazione"
        lbVersioneNumero.text = releaseVersionNumber
        lbVersioneNumero.font = UIFont.boldSystemFont(ofSize: 22.0)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func changeDB(_ sender: UITextField) {
        //print(textFieldDB.text)
        UserDefaults.standard.set(textFieldDB.text, forKey: "nameDB")
    }
    
    @IBAction func changeDBEnd(_ sender: UITextField) {
        //print(textFieldDB.text)
        UserDefaults.standard.set(textFieldDB.text, forKey: "nameDB")
    }
}
