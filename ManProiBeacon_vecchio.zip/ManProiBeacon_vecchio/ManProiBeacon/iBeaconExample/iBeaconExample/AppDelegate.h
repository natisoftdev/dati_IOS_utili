//
//  AppDelegate.h
//  iBeaconExample
//
//  Created by Natisoft on 27/03/19.
//  Copyright © 2019 Natisoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@import CoreLibraries;

@end

#import
@import CoreLocation;
@interface AppDelegate : UIResponder
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) CLLocationManager *locationManager;
@end
