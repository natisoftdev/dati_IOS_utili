//
//  ViewController.h
//  iBeaconExample
//
//  Created by Natisoft on 27/03/19.
//  Copyright © 2019 Natisoft. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property IBOutlet UITableView *tableView;
@property (strong) NSArray *beacons;

@end
