//
//  ViewController.m
//  iBeaconExample
//
//  Created by Natisoft on 27/03/19.
//  Copyright © 2019 Natisoft. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (NSInteger) tableView:(UITableView *)tableView
  numberOfRowsInSection:(NSInteger)section {
    return self.beacons.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MyIdentifier"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    CLBeacon *beacon = (CLBeacon *)[self.beacons objectAtIndex:indexPath.row];
    NSString *proximityLabel = @"";
    switch (beacon.proximity) {
        case CLProximityFar:
            proximityLabel = @"Lontano";
            break;
        case CLProximityNear:
            proximityLabel = @"Vicino";
            break;
        case CLProximityImmediate:
            proximityLabel = @"Immediato";
            break;
        case CLProximityUnknown:
            proximityLabel = @"Sconosciuto";
            break;
    }
    cell.textLabel.text = proximityLabel;
    NSString *detailLabel = [NSString stringWithFormat: @"Major: %d, Minor: %d, RSSI: %d, UUID: %@", beacon.major.intValue, beacon.minor.intValue, (int)beacon.rssi, beacon.proximityUUID.UUIDString];
    cell.detailTextLabel.text = detailLabel;
    return cell;
}

@end
